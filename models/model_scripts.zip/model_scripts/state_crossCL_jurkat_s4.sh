module load miniforge/25.9.1
eval "$(conda shell.bash hook)"
conda activate agop
set -eo pipefail

state tx train \
  data.kwargs.toml_config_path="/mnt/storage01/home/amolina/benchmark_2026/runs/STATE_crossCL/jurkat/seed4/config.toml" \
  data.kwargs.embed_key=X_hvg \
  data.kwargs.output_space=gene \
  data.kwargs.pert_rep=onehot \
  data.kwargs.basal_rep=sample \
  data.kwargs.num_workers=2 \
  data.kwargs.pin_memory=true \
  data.kwargs.n_basal_samples=1 \
  data.kwargs.basal_mapping_strategy=random \
  data.kwargs.should_yield_control_cells=true \
  data.kwargs.batch_col=gem_group \
  data.kwargs.pert_col=gene \
  data.kwargs.cell_type_key=cell_line \
  data.kwargs.control_pert=non-targeting \
  data.kwargs.map_controls=true \
  data.kwargs.store_raw_basal=false \
  data.kwargs.int_counts=false \
  data.kwargs.barcode=true \
  ++data.kwargs.downsample_cells=100 \
  training.max_steps=80000 \
  training.ckpt_every_n_steps=5000 \
  training.batch_size=8 \
  training.lr=1e-3 \
  training.train_seed=4 \
  model=state \
  model.kwargs.cell_set_len=32 \
  model.kwargs.hidden_dim=128 \
  model.kwargs.transformer_backbone_key=GPT2 \
  model.kwargs.n_encoder_layers=4 \
  model.kwargs.n_decoder_layers=4 \
  model.kwargs.predict_residual=true \
  model.kwargs.batch_encoder=false \
  model.kwargs.use_batch_token=false \
  model.kwargs.transformer_backbone_kwargs.num_attention_heads=8 \
  model.kwargs.transformer_backbone_kwargs.num_key_value_heads=8 \
  output_dir=/mnt/storage01/home/amolina/benchmark_2026/runs/STATE_crossCL/jurkat/seed4/run \
  name=crossCL_jurkat_seed4
