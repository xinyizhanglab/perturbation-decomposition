module load miniforge/25.9.1
eval "$(conda shell.bash hook)"
conda activate agop
set -eo pipefail
export WANDB_MODE=disabled

MORPH_REPO="/mnt/storage01/home/amolina/agop-perturbation/morph_pipeline/MORPH"
MORPH_BENCH="/mnt/storage01/home/amolina/benchmark_2026/morph_crosscl"
DATA_DIR="/mnt/storage01/home/amolina/benchmark_2026/morph_crosscl/data"
SAVEDIR="/mnt/storage01/home/amolina/benchmark_2026/morph_crosscl/runs/rpe1_to_k562/seed3/source_model"

# ── Step A: Train MORPH on source CL ──
mkdir -p $SAVEDIR
cd $MORPH_REPO/morph

ln -sf $DATA_DIR/scdata_file_path.csv $MORPH_REPO/data/scdata_file_path_bench.csv
ln -sf $DATA_DIR/perturb_embed_file_path.csv $MORPH_REPO/data/perturb_embed_file_path_bench.csv

python3 -u run.py \
  --random_seed 3 \
  --dataset_name rpe1_hvg \
  --leave_out_test_set_id cross_cl_val \
  --device cuda:0 \
  --model MORPH \
  --label DepMap_GeneEffect \
  --epochs 100 \
  --batch_size 32 \
  --MMD_sigma 1500 \
  --Gamma1 1.0 --reconstruction_loss mse \
  --tolerance_epochs 20

echo "Source training done"

LATEST=$(ls -td $MORPH_REPO/result/rna/rpe1_hvg/cross_cl_val/DepMap_GeneEffect_MORPH_run* 2>/dev/null | head -1)
if [ -z "$LATEST" ]; then
    echo "ERROR: no result directory found"
    exit 1
fi
echo "Source model at: $LATEST"
cp $LATEST/best_model.pt $SAVEDIR/
cp $LATEST/config.json $SAVEDIR/

# ── Step B: 3-way inference ──
echo "Starting 3-way inference..."
python3 -u /mnt/storage01/home/amolina/benchmark_2026/scripts/morph_crosscl_3way.py \
  --source rpe1 --target k562 --seed 3 \
  --model_path $SAVEDIR/best_model.pt \
  --config_path $SAVEDIR/config.json

echo "Done: rpe1 -> k562 seed 3"
