#!/usr/bin/env python
"""Canonical scGPT perturbation prediction — faithful to the official tutorial.

Uses GEARS PertData, TransformerGenerator, proper pert_flags, fine-tuning,
and the reference inference protocol (control pool).

Usage:
    python scripts/run_scgpt_baseline.py \
        --dataset adamson \
        --scgpt_ckpt ../save/scGPT_human \
        --seed 1 --epochs 15 --device cuda:0 \
        --outdir outputs/scgpt_baseline

Reference: scGPT Tutorial_Perturbation.ipynb
    https://github.com/bowang-lab/scGPT/blob/main/tutorials/Tutorial_Perturbation.ipynb
"""
from __future__ import annotations

import argparse
import copy
import csv
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Optional

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)
logger = logging.getLogger("scgpt_baseline")

# ═══════════════════════════════════════════════════════════════════════
# 0. Imports — scGPT + GEARS (fail fast if not installed)
# ═══════════════════════════════════════════════════════════════════════

try:
    from gears import PertData
    from gears.utils import create_cell_graph_dataset_for_prediction
except ImportError as e:
    raise ImportError(
        f"GEARS is required: pip install gears\nOriginal error: {e}"
    )

try:
    from scgpt.model import TransformerGenerator
    from scgpt.loss import masked_mse_loss
    from scgpt.tokenizer.gene_tokenizer import GeneVocab
    from scgpt.utils import set_seed, map_raw_id_to_vocab_id
except ImportError as e:
    raise ImportError(
        f"scGPT is required: pip install scgpt\nOriginal error: {e}"
    )

from torch_geometric.loader import DataLoader

# ═══════════════════════════════════════════════════════════════════════
# Reference hyperparameters (from Tutorial_Perturbation.ipynb)
# ═══════════════════════════════════════════════════════════════════════

DEFAULT_CONFIG = {
    # Model architecture (must match pretrained checkpoint)
    "embsize": 512,
    "d_hid": 512,
    "nlayers": 12,
    "nhead": 8,
    "n_layers_cls": 3,
    "dropout": 0.2,
    # Training
    "lr": 1e-4,
    "batch_size": 64,
    "eval_batch_size": 64,
    "epochs": 15,
    "early_stop": 5,
    "schedule_interval": 1,
    "grad_clip": 1.0,
    # Input handling
    "include_zero_gene": "all",
    "max_seq_len": 1536,                # ★ FIX 1: was 10000
    # scGPT settings
    "CLS": False,
    "CCE": False,
    "MVC": False,
    "ECS": False,
    "amp": True,
    # Partial weight loading (from pretrained)
    "load_param_prefixes": ["encoder", "value_encoder", "transformer_encoder"],
    # Inference
    "pool_size": None,  # None = use all controls
    # Special tokens
    "special_tokens": ["<pad>", "<cls>", "<eoc>"],
    # Split
    "split": "simulation",
    "train_perts_file": None,
    "test_perts_file": None,
}


# ═══════════════════════════════════════════════════════════════════════
# 1. Data loading (via GEARS — canonical pipeline)
# ═══════════════════════════════════════════════════════════════════════

def load_data(data_name: str, data_dir: str, seed: int, batch_size: int,
              eval_batch_size: int, split: str = "simulation",
              train_perts_file: str = None, test_perts_file: str = None):
    """Load dataset using GEARS PertData — matches reference exactly."""
    pert_data = PertData(data_dir)
    import os as _os
    _known = {"adamson", "norman", "dixit", "norman2"}
    if data_name.lower() in _known:
        pert_data.load(data_name=data_name)
    else:
        _dp = _os.path.join(data_dir, data_name)
        logger.info(f"Loading non-standard dataset from {_dp}")
        pert_data.load(data_path=_dp)
    pert_data.prepare_split(split=split, seed=seed)
    if train_perts_file is not None:
        logger.info(f"Overriding GEARS split with canonical split files...")
        with open(train_perts_file) as _f:
            _canon_train = set(l.strip() for l in _f if l.strip())
        with open(test_perts_file) as _f:
            _canon_test = set(l.strip() for l in _f if l.strip())
        # GEARS uses +ctrl suffix format
        _existing = set(pert_data.set2conditions.get("train", set()) |
                        pert_data.set2conditions.get("test", set()))
        _has_ctrl = any("+ctrl" in p for p in list(_existing)[:10])
        if _has_ctrl and not any("+ctrl" in p for p in list(_canon_test)[:10]):
            _canon_train = set(p + "+ctrl" for p in _canon_train)
            _canon_test = set(p + "+ctrl" for p in _canon_test)
        pert_data.set2conditions = {"train": _canon_train, "test": _canon_test, "val": set()}
        # Re-assign split column in adata
        adata = pert_data.adata
        cond_col = "condition" if "condition" in adata.obs.columns else "perturbation"
        adata.obs["split"] = "unassigned"
        for idx, cond in enumerate(adata.obs[cond_col]):
            if cond in _canon_train or cond == "ctrl":
                adata.obs.iloc[idx, adata.obs.columns.get_loc("split")] = "train"
            elif cond in _canon_test:
                adata.obs.iloc[idx, adata.obs.columns.get_loc("split")] = "test"
        logger.info(f"  Canonical: {len(_canon_train)} train, {len(_canon_test)} test")
    pert_data.get_dataloader(batch_size=batch_size, test_batch_size=eval_batch_size)

    # Log diagnostics
    adata = pert_data.adata
    n_genes = adata.shape[1]
    n_cells = adata.shape[0]
    n_perts = len(set(adata.obs["condition"].unique()) - {"ctrl"})

    logger.info(f"Dataset: {data_name}")
    logger.info(f"  #genes: {n_genes}, #cells: {n_cells}, #perts: {n_perts}")

    # Log split composition
    if "split" in adata.obs:
        for s in ["train", "val", "test"]:
            mask = adata.obs["split"] == s
            n_cells_s = mask.sum()
            n_perts_s = len(set(adata.obs.loc[mask, "condition"].unique()) - {"ctrl"})
            logger.info(f"  {s}: {n_cells_s} cells, {n_perts_s} perts")

    return pert_data


# ═══════════════════════════════════════════════════════════════════════
# 2. Gene vocabulary setup (from reference)
# ═══════════════════════════════════════════════════════════════════════

def setup_vocab(pert_data, model_dir: Path, special_tokens: list[str]):
    """Setup gene vocab matching reference exactly.

    Returns:
        vocab: GeneVocab object
        gene_ids: np.ndarray of shape (n_genes,) where gene_ids[i] is the
                  vocab token ID for the i-th gene in pert_data. Used by
                  map_raw_id_to_vocab_id(raw_ids, gene_ids) which does
                  gene_ids[raw_ids] to map positional indices to vocab IDs.
    """
    vocab_file = model_dir / "vocab.json"
    vocab = GeneVocab.from_file(vocab_file)
    logger.info(f"Loaded vocab: {len(vocab)} tokens from {vocab_file}")

    # Append special tokens if missing
    for s in special_tokens:
        if s not in vocab:
            vocab.append_token(s)
    logger.info(f"Vocab after special tokens: {len(vocab)}")

    # Check coverage (for logging only)
    genes = pert_data.adata.var["gene_name"].tolist()
    pert_data.adata.var["id_in_vocab"] = [
        1 if gene in vocab else -1
        for gene in genes
    ]
    n_matched = (np.array(pert_data.adata.var["id_in_vocab"]) >= 0).sum()
    n_total = len(genes)
    logger.info(f"Gene match: {n_matched}/{n_total} genes in vocab")

    if n_matched / n_total < 0.5:
        logger.warning(f"  Only {n_matched}/{n_total} genes matched — check gene naming!")

    # Build the actual mapping array: gene_ids[i] = vocab token ID for gene i
    # This is what map_raw_id_to_vocab_id indexes into
    gene_ids = np.array(vocab(genes), dtype=int)

    # Sanity check
    logger.info(f"  gene_ids range: [{gene_ids.min()}, {gene_ids.max()}], "
                f"vocab size: {len(vocab)}")
    assert gene_ids.max() < len(vocab), (
        f"gene_ids max {gene_ids.max()} >= vocab size {len(vocab)}!"
    )

    return vocab, gene_ids


# ═══════════════════════════════════════════════════════════════════════
# 3. Model construction is done directly in main() to match the tutorial
# ═══════════════════════════════════════════════════════════════════════


# ═══════════════════════════════════════════════════════════════════════
# 4. Training loop (from reference Tutorial_Perturbation.ipynb)
# ═══════════════════════════════════════════════════════════════════════

def train_epoch(model, train_loader, optimizer, scheduler, scaler, device,
                config, gene_ids):
    """One training epoch — matches reference exactly."""
    model.train()
    total_loss, total_mse = 0.0, 0.0
    n_genes = len(gene_ids)
    max_seq_len = config["max_seq_len"]
    include_zero_gene = config["include_zero_gene"]

    for batch_idx, batch_data in enumerate(train_loader):
        batch_size = len(batch_data.y)
        batch_data.to(device)

        x = batch_data.x  # (batch_size * n_genes, 2)
        ori_gene_values = x[:, 0].view(batch_size, n_genes)
        pert_flags = x[:, 1].long().view(batch_size, n_genes)
        target_gene_values = batch_data.y  # (batch_size, n_genes)

        # Gene selection
        if include_zero_gene == "all":
            input_gene_ids = torch.arange(n_genes, device=device, dtype=torch.long)
        else:
            input_gene_ids = (
                ori_gene_values.nonzero()[:, 1].flatten().unique().sort()[0]
            )

        # Subsample if exceeding max_seq_len
        if len(input_gene_ids) > max_seq_len:
            input_gene_ids = torch.randperm(len(input_gene_ids), device=device)[
                :max_seq_len
            ]

        input_values = ori_gene_values[:, input_gene_ids]
        input_pert_flags = pert_flags[:, input_gene_ids]
        target_values = target_gene_values[:, input_gene_ids]

        # Map to vocab IDs
        mapped_input_gene_ids = map_raw_id_to_vocab_id(
            input_gene_ids, gene_ids
        )
        mapped_input_gene_ids = mapped_input_gene_ids.repeat(batch_size, 1)

        # Padding mask (no padding when using all genes)
        src_key_padding_mask = torch.zeros_like(
            input_values, dtype=torch.bool, device=device
        )

        # Forward pass with AMP
        with torch.cuda.amp.autocast(enabled=config["amp"]):
            output_dict = model(
                mapped_input_gene_ids,
                input_values,
                input_pert_flags,         # <-- CRITICAL: pert flags as 3rd arg
                src_key_padding_mask,
                CLS=config["CLS"],
                CCE=config["CCE"],
                MVC=config["MVC"],
                ECS=config["ECS"],
            )
            output_values = output_dict["mlm_output"]
            # masked_mse_loss expects mask where True = compute loss
            # We want loss on ALL positions (reference uses all-True mask)
            loss_mask = torch.ones_like(
                input_values, dtype=torch.bool, device=device
            )
            loss_mse = masked_mse_loss(output_values, target_values, loss_mask)
            loss = loss_mse

        # Backward
        model.zero_grad()
        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), config["grad_clip"])
        scaler.step(optimizer)
        scaler.update()

        total_loss += loss.item() * batch_size
        total_mse += loss_mse.item() * batch_size

    scheduler.step()
    n_samples = len(train_loader.dataset)
    return total_loss / n_samples, total_mse / n_samples


def evaluate(model, val_loader, device, config, gene_ids):
    """Validation — matches reference (loss-based, used for early stopping)."""
    model.eval()
    total_loss = 0.0
    total_error = 0.0
    n_genes = len(gene_ids)
    max_seq_len = config["max_seq_len"]
    include_zero_gene = config["include_zero_gene"]
    criterion = masked_mse_loss

    with torch.no_grad():
        for batch_data in val_loader:
            batch_size = len(batch_data.y)
            batch_data.to(device)

            x = batch_data.x
            ori_gene_values = x[:, 0].view(batch_size, n_genes)
            pert_flags = x[:, 1].long().view(batch_size, n_genes)
            target_gene_values = batch_data.y

            if include_zero_gene == "all":
                input_gene_ids = torch.arange(n_genes, device=device, dtype=torch.long)
            else:
                input_gene_ids = (
                    ori_gene_values.nonzero()[:, 1].flatten().unique().sort()[0]
                )

            if len(input_gene_ids) > max_seq_len:
                input_gene_ids = torch.randperm(len(input_gene_ids), device=device)[
                    :max_seq_len
                ]

            input_values = ori_gene_values[:, input_gene_ids]
            input_pert_flags = pert_flags[:, input_gene_ids]
            target_values = target_gene_values[:, input_gene_ids]

            mapped_input_gene_ids = map_raw_id_to_vocab_id(
                input_gene_ids, gene_ids
            )
            mapped_input_gene_ids = mapped_input_gene_ids.repeat(batch_size, 1)

            src_key_padding_mask = torch.zeros_like(
                input_values, dtype=torch.bool, device=device
            )

            with torch.cuda.amp.autocast(enabled=config["amp"]):
                output_dict = model(
                    mapped_input_gene_ids,
                    input_values,
                    input_pert_flags,
                    src_key_padding_mask,
                    CLS=config["CLS"],
                    CCE=config["CCE"],
                    MVC=config["MVC"],
                    ECS=config["ECS"],
                    do_sample=True,
                )
                output_values = output_dict["mlm_output"]

                masked_positions = torch.ones_like(
                    input_values, dtype=torch.bool, device=device
                )
                loss = criterion(output_values, target_values, masked_positions)

            total_loss += loss.item()

    return total_loss / len(val_loader)


# ═══════════════════════════════════════════════════════════════════════
# 5. Inference (reference control-pool protocol)
# ═══════════════════════════════════════════════════════════════════════

def predict_perturbations(
    model,
    pert_data,
    pert_list: list[list[str]],
    gene_ids: np.ndarray,
    config: dict,
    device: str,
):
    """
    Reference inference using model.pred_perturb() and GEARS utilities.
    This is the EXACT protocol from Tutorial_Perturbation.ipynb:

        for pert in pert_list:
            cell_graphs = create_cell_graph_dataset_for_prediction(...)
            loader = DataLoader(cell_graphs, ...)
            for batch_data in loader:
                pred = model.pred_perturb(batch_data, include_zero_gene, gene_ids, amp)
    """
    model.eval()

    adata = pert_data.adata
    ctrl_adata = adata[adata.obs["condition"] == "ctrl"]
    pool_size = config.get("pool_size", None)
    if pool_size is None:
        pool_size = len(ctrl_adata.obs)

    gene_list = pert_data.gene_names.values.tolist()
    n_genes = len(gene_list)
    include_zero_gene = config["include_zero_gene"]
    amp = config["amp"]

    results_pred = {}

    with torch.no_grad():
        for pi, pert in enumerate(pert_list):
            # Validate genes exist
            skip = False
            for g in pert:
                if g not in gene_list:
                    logger.warning(f"  Gene '{g}' not in gene_list — skipping {pert}")
                    skip = True
                    break
            if skip:
                continue

            try:
                cell_graphs = create_cell_graph_dataset_for_prediction(
                    pert, ctrl_adata, gene_list, device, num_samples=pool_size
                )
            except Exception as e:
                logger.warning(f"  Failed for {pert}: {e}")
                continue

            loader = DataLoader(
                cell_graphs,
                batch_size=config["eval_batch_size"],
                shuffle=False,
            )

            preds = []
            for batch_data in loader:
                pred_gene_values = model.pred_perturb(
                    batch_data, include_zero_gene,
                    gene_ids=gene_ids, amp=amp,
                )
                preds.append(pred_gene_values)

            preds = torch.cat(preds, dim=0)
            pert_key = "+".join(pert)
            results_pred[pert_key] = np.mean(
                preds.detach().cpu().numpy(), axis=0
            )

            if (pi + 1) % 10 == 0:
                logger.info(f"  Predicted {pi+1}/{len(pert_list)} perturbations")

    logger.info(f"  Total: {len(results_pred)} perturbations predicted")
    return results_pred


# ═══════════════════════════════════════════════════════════════════════
# 6. Metrics (our metrics + GEARS reference)
# ═══════════════════════════════════════════════════════════════════════

def compute_our_metrics(results_pred, pert_data, gene_list):
    """Compute per-pert Pearson, cosine, etc. on deltas.

    results_pred: dict mapping pert_key -> pred_mean (1D array of length n_genes)
    """
    adata = pert_data.adata
    ctrl_mean = adata[adata.obs["condition"] == "ctrl"].X
    if hasattr(ctrl_mean, "toarray"):
        ctrl_mean = ctrl_mean.toarray()
    ctrl_mean = np.asarray(ctrl_mean, dtype=np.float64).mean(axis=0)

    rows = []
    for pert_key, pred_mean in results_pred.items():
        # Ground truth: mean of perturbed cells
        # Match both "GENE+ctrl" and "GENE" formats in condition column
        cond_mask = adata.obs["condition"] == pert_key
        if cond_mask.sum() == 0:
            # Try alternative formats: "GENE+ctrl", "ctrl+GENE", original order
            genes = pert_key.split("+")
            for alt in ["+".join(genes + ["ctrl"]),
                        "+".join(["ctrl"] + genes),
                        "+".join(reversed(genes))]:
                cond_mask = adata.obs["condition"] == alt
                if cond_mask.sum() > 0:
                    break
        pert_cells = adata[cond_mask].X
        if hasattr(pert_cells, "toarray"):
            pert_cells = pert_cells.toarray()
        pert_cells = np.asarray(pert_cells, dtype=np.float64)

        if len(pert_cells) == 0:
            continue

        y_true = pert_cells.mean(axis=0)
        y_pred = np.asarray(pred_mean, dtype=np.float64)

        delta_true = y_true - ctrl_mean
        delta_pred = y_pred - ctrl_mean

        # Pearson on deltas (all genes)
        pearson_all = float(np.corrcoef(delta_true, delta_pred)[0, 1])

        # Cosine on deltas
        nt = np.linalg.norm(delta_true)
        np_ = np.linalg.norm(delta_pred)
        cosine = float(np.dot(delta_true, delta_pred) / max(nt * np_, 1e-12))

        # MSE on deltas
        mse = float(((delta_true - delta_pred) ** 2).mean())

        # Top-20 DE genes
        top20_idx = np.argsort(np.abs(delta_true))[::-1][:20]
        pearson_top20 = float(np.corrcoef(delta_true[top20_idx], delta_pred[top20_idx])[0, 1])

        rows.append({
            "pert": pert_key,
            "pearson_delta": round(pearson_all, 6),
            "pearson_top20_de": round(pearson_top20, 6),
            "cosine_delta": round(cosine, 6),
            "mse": round(mse, 6),
            "delta_norm": round(float(np.linalg.norm(delta_true)), 4),
        })

    return rows


def export_npz(results_pred, pert_data, outdir: Path, dataset_name: str, split: str):
    """Export in the canonical format our analysis scripts expect."""
    adata = pert_data.adata
    gene_names = pert_data.gene_names.values.tolist()

    ctrl_mean = adata[adata.obs["condition"] == "ctrl"].X
    if hasattr(ctrl_mean, "toarray"):
        ctrl_mean = ctrl_mean.toarray()
    ctrl_mean = np.asarray(ctrl_mean, dtype=np.float32).mean(axis=0)

    pert_names, y_true_list, y_pred_list = [], [], []
    for pert_key, pred_mean in sorted(results_pred.items()):
        # Match both "GENE+ctrl" and "GENE" formats
        cond_mask = adata.obs["condition"] == pert_key
        if cond_mask.sum() == 0:
            genes = pert_key.split("+")
            for alt in ["+".join(genes + ["ctrl"]),
                        "+".join(["ctrl"] + genes),
                        "+".join(reversed(genes))]:
                cond_mask = adata.obs["condition"] == alt
                if cond_mask.sum() > 0:
                    break
        pert_cells = adata[cond_mask].X
        if hasattr(pert_cells, "toarray"):
            pert_cells = pert_cells.toarray()
        pert_cells = np.asarray(pert_cells, dtype=np.float32)
        if len(pert_cells) == 0:
            continue

        pert_names.append(pert_key)
        y_true_list.append(pert_cells.mean(axis=0))
        y_pred_list.append(np.asarray(pred_mean, dtype=np.float32))

    if not pert_names:
        logger.warning("No valid perturbations to export")
        return

    npz_dir = outdir / dataset_name / split
    npz_dir.mkdir(parents=True, exist_ok=True)
    npz_path = npz_dir / "scgpt_finetuned.npz"

    np.savez_compressed(
        npz_path,
        y_true=np.stack(y_true_list),
        y_pred=np.stack(y_pred_list),
        pert_names=np.array(pert_names, dtype=object),
        gene_names=np.array(gene_names, dtype=object),
        control_mean=ctrl_mean,
    )
    logger.info(f"Exported {len(pert_names)} perts to {npz_path}")


# ═══════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="scGPT baseline — reference implementation")
    parser.add_argument("--dataset", type=str, required=True,
                        # choices removed for benchmark
                        # choices=["adamson", "norman", "replogle_k562_essential",
                        #          "replogle_rpe1_essential"],
                        help="GEARS dataset name")
    parser.add_argument("--data_dir", type=str, default="./data")
    parser.add_argument("--scgpt_ckpt", type=str, required=True,
                        help="Path to pretrained scGPT checkpoint dir (e.g. save/scGPT_human)")
    parser.add_argument("--outdir", type=str, default="outputs/scgpt_baseline")
    parser.add_argument("--train_perts_file", type=str, default=None,
                        help="Canonical train split file")
    parser.add_argument("--test_perts_file", type=str, default=None,
                        help="Canonical test split file")
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--epochs", type=int, default=15)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--device", type=str, default="cuda:0")
    parser.add_argument("--skip_train", action="store_true",
                        help="Skip training, load fine-tuned model from outdir")
    args = parser.parse_args()

    set_seed(args.seed)
    t0 = time.time()

    config = dict(DEFAULT_CONFIG)
    config["epochs"] = args.epochs
    config["batch_size"] = args.batch_size
    config["lr"] = args.lr

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    model_dir = Path(args.scgpt_ckpt)
    device = args.device

    logger.info("=" * 60)
    logger.info(f"scGPT Baseline — {args.dataset}")
    logger.info("=" * 60)

    # ── 1. Load data ─────────────────────────────────────────────────
    pert_data = load_data(
        args.dataset, args.data_dir, args.seed,
        config["batch_size"], config["eval_batch_size"],
        split=config["split"],
        train_perts_file=config.get("train_perts_file"),
        test_perts_file=config.get("test_perts_file"),
    )

    # ── 2. Setup vocab ───────────────────────────────────────────────
    vocab, gene_ids = setup_vocab(
        pert_data, model_dir, config["special_tokens"]
    )

    # ── 3. Build model ───────────────────────────────────────────────
    ntokens = len(vocab)
    n_genes = pert_data.adata.shape[1]

    # Load model config from args.json (reference approach)
    args_file = model_dir / "args.json"
    if args_file.exists():
        with open(args_file) as f:
            model_configs = json.load(f)
        logger.info(f"Loaded model config from {args_file}")
        # Override defaults with checkpoint config
        config["embsize"] = model_configs.get("embsize", config["embsize"])
        config["nhead"] = model_configs.get("nheads", config["nhead"])
        config["d_hid"] = model_configs.get("d_hid", config["d_hid"])
        config["nlayers"] = model_configs.get("nlayers", config["nlayers"])
        config["n_layers_cls"] = model_configs.get("n_layers_cls", config["n_layers_cls"])
        logger.info(f"  embsize={config['embsize']}, nhead={config['nhead']}, "
                    f"d_hid={config['d_hid']}, nlayers={config['nlayers']}")
    else:
        logger.warning(f"No args.json found in {model_dir}, using defaults")

    model = TransformerGenerator(
        ntoken=ntokens,
        d_model=config["embsize"],
        nhead=config["nhead"],
        d_hid=config["d_hid"],
        nlayers=config["nlayers"],
        nlayers_cls=config["n_layers_cls"],
        n_cls=1,
        vocab=vocab,
        dropout=config["dropout"],
        pad_token="<pad>",
        pad_value=0,                                    # ★ FIX 2: was -2
        pert_pad_id=2,
        do_mvc=config["MVC"],
        cell_emb_style="cls",
        mvc_decoder_style="inner product, detach",      # ★ FIX 3: was "inner product"
    )

    # Load pretrained weights — match ALL keys that fit, not just prefixed ones
    # The tutorial loads encoder, value_encoder, transformer_encoder prefixes
    model_file = model_dir / "best_model.pt"
    if model_file.exists():
        pretrained_dict = torch.load(model_file, map_location="cpu")
        model_dict = model.state_dict()

        # Log what's in the checkpoint vs our model
        logger.info(f"  Checkpoint keys: {len(pretrained_dict)}")
        logger.info(f"  Model keys: {len(model_dict)}")

        # First pass: see what matches by prefix
        for prefix in config["load_param_prefixes"]:
            ckpt_with_prefix = [k for k in pretrained_dict if k.startswith(prefix)]
            model_with_prefix = [k for k in model_dict if k.startswith(prefix)]
            logger.info(f"  Prefix '{prefix}': {len(ckpt_with_prefix)} in ckpt, "
                        f"{len(model_with_prefix)} in model")

        remapped_dict = {}
        for key, value in pretrained_dict.items():
            new_key = key
            if ".self_attn.Wqkv." in key:
                new_key = key.replace(".self_attn.Wqkv.", ".self_attn.in_proj_")
            if key.startswith("flag_encoder."):
                new_key = key.replace("flag_encoder.", "pert_encoder.")
            remapped_dict[new_key] = value
            if new_key != key:
                logger.info(f"  Key remap: {key} → {new_key}")
        pretrained_dict = remapped_dict

        # Load matching params
        loaded, skipped_shape, skipped_prefix = 0, 0, 0
        for key, value in pretrained_dict.items():
            if any(key.startswith(p) for p in config["load_param_prefixes"]):
                if key in model_dict:
                    if model_dict[key].shape == value.shape:
                        model_dict[key] = value
                        loaded += 1
                    else:
                        logger.warning(f"  Shape mismatch: {key} "
                                       f"ckpt={value.shape} model={model_dict[key].shape}")
                        skipped_shape += 1
                else:
                    skipped_prefix += 1
            else:
                skipped_prefix += 1

        model.load_state_dict(model_dict)
        logger.info(f"Loaded {loaded} pretrained params "
                    f"(skipped: {skipped_shape} shape mismatch, "
                    f"{skipped_prefix} not in target model)")

        if loaded < 50:
            logger.warning(f"  Only {loaded} params loaded — likely key name mismatch!")
            # Show first 10 keys from each for debugging
            ckpt_keys = sorted(pretrained_dict.keys())[:10]
            model_keys = sorted(model_dict.keys())[:10]
            logger.warning(f"  Checkpoint keys (first 10): {ckpt_keys}")
            logger.warning(f"  Model keys (first 10): {model_keys}")
    else:
        logger.error(f"No pretrained weights at {model_file}!")

    try:
        from scgpt.model.model import ExprDecoder

        class ExprDecoderCompat(ExprDecoder):
            """ExprDecoder that accepts (and ignores) the extra `values` arg.

            TransformerGenerator.forward() calls self.decoder(transformer_output, values).
            AffineExprDecoder uses `values` for its skip connection: pred = A(h)*values + b(h).
            ExprDecoder only needs transformer_output: pred = MLP(h).
            We accept `values` so the calling convention doesn't break, but ignore it.
            """
            def forward(self, x, values=None):
                return super().forward(x)

        old_decoder_type = type(model.decoder).__name__
        model.decoder = ExprDecoderCompat(
            d_model=config["embsize"],
            explicit_zero_prob=False,
        )
        logger.info(f"★ Replaced {old_decoder_type} → ExprDecoderCompat (no skip connection)")
    except ImportError:
        logger.warning(
            "Could not import ExprDecoder from scgpt.model.model — "
            "keeping AffineExprDecoder. This may cause mode collapse."
        )

    model.to(device)
    logger.info(f"Model: {sum(p.numel() for p in model.parameters()):,} params")

    # ── 4. Fine-tune ─────────────────────────────────────────────────
    save_dir = outdir / f"model_{args.dataset}_seed{args.seed}"
    save_dir.mkdir(parents=True, exist_ok=True)

    if args.skip_train:
        ckpt = save_dir / "best_model.pt"
        if ckpt.exists():
            model.load_state_dict(torch.load(ckpt, map_location=device))
            logger.info(f"Loaded fine-tuned model from {ckpt}")
        else:
            logger.error(f"No fine-tuned model at {ckpt} and --skip_train set!")
            sys.exit(1)
    else:
        optimizer = torch.optim.Adam(model.parameters(), lr=config["lr"])
        scheduler = torch.optim.lr_scheduler.StepLR(
            optimizer, config["schedule_interval"], gamma=0.9
        )
        scaler = torch.cuda.amp.GradScaler(enabled=config["amp"])

        best_val_loss = float("inf")
        patience = 0
        best_model_state = None

        train_loader = pert_data.dataloader["train_loader"]
        val_loader = pert_data.dataloader["val_loader"]

        for epoch in range(1, config["epochs"] + 1):
            t_ep = time.time()
            train_loss, train_mse = train_epoch(
                model, train_loader, optimizer, scheduler, scaler,
                device, config, gene_ids,
            )
            val_loss = evaluate(model, val_loader, device, config, gene_ids)

            elapsed = time.time() - t_ep
            logger.info(
                f"Epoch {epoch:2d}/{config['epochs']} | "
                f"train_loss={train_loss:.4f} train_mse={train_mse:.4f} | "
                f"val_loss={val_loss:.4f} | {elapsed:.1f}s"
            )

            if val_loss < best_val_loss:
                best_val_loss = val_loss
                patience = 0
                best_model_state = copy.deepcopy(model.state_dict())
                # Save periodic checkpoint for AGOP dynamics
                torch.save(model.state_dict(), save_dir / f"checkpoint_epoch_{epoch}.pt")
            else:
                patience += 1
                if patience >= config["early_stop"]:
                    logger.info(f"Early stopping at epoch {epoch}")
                    break

        # Save best model
        if best_model_state is not None:
            model.load_state_dict(best_model_state)
            torch.save(best_model_state, save_dir / "best_model.pt")
            logger.info(f"Best model saved to {save_dir}/best_model.pt (val_loss={best_val_loss:.4f})")

    # ── 5. Inference ─────────────────────────────────────────────────
    logger.info("\n" + "=" * 60)
    logger.info("Inference (test perturbations)")
    logger.info("=" * 60)

    # Get test perturbation list from the dataloader
    test_loader = pert_data.dataloader["test_loader"]
    test_pert_list = []
    test_pert_set = set()
    for batch_data in test_loader:
        for pert in batch_data.pert:
            # pert is a string like "CREB1+ctrl" or "CBL+PTPN9"
            if isinstance(pert, str):
                genes = [g for g in pert.split("+") if g != "ctrl"]
            elif isinstance(pert, (list, tuple)):
                genes = [g for g in pert if g != "ctrl"]
            else:
                genes = [str(pert)]
            if not genes:
                continue
            pert_key = tuple(sorted(genes))
            if pert_key not in test_pert_set:
                test_pert_set.add(pert_key)
                test_pert_list.append(list(genes))

    logger.info(f"Test perturbations: {len(test_pert_list)}")

    results_pred = predict_perturbations(
        model, pert_data, test_pert_list,
        gene_ids, config, device,
    )
    logger.info(f"Predicted {len(results_pred)} perturbations")

    # ── 6. Our metrics (Pearson on deltas, cosine, etc.) ────────────
    logger.info("\n" + "=" * 60)
    logger.info("Metrics (delta-based)")
    logger.info("=" * 60)

    # ── 6. Metrics ───────────────────────────────────────────────────
    gene_list = pert_data.gene_names.values.tolist()
    metrics = compute_our_metrics(results_pred, pert_data, gene_list)

    if metrics:
        pearson_vals = [m["pearson_delta"] for m in metrics]
        cosine_vals = [m["cosine_delta"] for m in metrics]
        top20_vals = [m["pearson_top20_de"] for m in metrics]

        logger.info(f"\n{'='*60}")
        logger.info(f"RESULTS: {args.dataset} (seed={args.seed})")
        logger.info(f"{'='*60}")
        logger.info(f"  Mean Pearson(Δ):    {np.mean(pearson_vals):.4f}")
        logger.info(f"  Median Pearson(Δ):  {np.median(pearson_vals):.4f}")
        logger.info(f"  Mean Cosine(Δ):     {np.mean(cosine_vals):.4f}")
        logger.info(f"  Mean Top-20 DE:     {np.mean(top20_vals):.4f}")
        logger.info(f"  #perts evaluated:   {len(metrics)}")

        # Save metrics
        metrics_path = outdir / f"metrics_{args.dataset}_seed{args.seed}.csv"
        import pandas as pd
        pd.DataFrame(metrics).to_csv(metrics_path, index=False)
        logger.info(f"Metrics saved to {metrics_path}")

    # ── 7. Export NPZ ────────────────────────────────────────────────
    export_npz(results_pred, pert_data, outdir / "preds", args.dataset, "test")

    # ── Metadata ─────────────────────────────────────────────────────
    meta = {
        "dataset": args.dataset,
        "seed": args.seed,
        "epochs": config["epochs"],
        "lr": config["lr"],
        "batch_size": config["batch_size"],
        "n_test_perts": len(results_pred),
        "elapsed_s": round(time.time() - t0, 1),
        "fixes_applied": [
            "max_seq_len=1536 (was 10000)",
            "pad_value=0 (was -2)",
            "mvc_decoder_style='inner product, detach' (was 'inner product')",
            "ExprDecoderCompat (replaced AffineExprDecoder, no skip connection)",
        ],
    }
    if metrics:
        meta["mean_pearson_delta"] = round(float(np.mean(pearson_vals)), 6)
        meta["mean_cosine_delta"] = round(float(np.mean(cosine_vals)), 6)

    (outdir / f"meta_{args.dataset}_seed{args.seed}.json").write_text(
        json.dumps(meta, indent=2) + "\n"
    )

    logger.info(f"\nDone in {meta['elapsed_s']}s")


if __name__ == "__main__":
    main()