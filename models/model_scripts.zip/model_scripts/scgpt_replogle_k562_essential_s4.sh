module load miniforge/25.9.1
eval "$(conda shell.bash hook)"
conda activate agop
export PYTHONNOUSERSITE=1
set -eo pipefail

cd /mnt/storage01/home/amolina/agop-perturbation

python3 /mnt/storage01/home/amolina/benchmark_2026/scripts/run_scgpt_benchmark.py \
    --dataset replogle_k562_essential \
    --data_dir /mnt/storage01/home/amolina/benchmark_2026/data/gears \
    --scgpt_ckpt /mnt/storage01/home/amolina/agop-perturbation/data/raw/scgpt_pretrained \
    --outdir /mnt/storage01/home/amolina/benchmark_2026/runs/scGPT/replogle_k562_essential/seed4 \
    --train_perts_file /mnt/storage01/home/amolina/benchmark_2026/data/gears/replogle_k562_essential/train_perts.txt \
    --test_perts_file /mnt/storage01/home/amolina/benchmark_2026/data/gears/replogle_k562_essential/test_perts.txt \
    --seed 4 \
    --epochs 15 \
    --batch_size 64 \
    --device cuda:0

# Convert output to benchmark format
python3 -u << 'PYEOF'
import json, numpy as np
from pathlib import Path

outdir = Path("/mnt/storage01/home/amolina/benchmark_2026/runs/scGPT/replogle_k562_essential/seed4")
ds = "replogle_k562_essential"
seed = 4

# Find the exported NPZ
npz_candidates = list(outdir.glob("preds/replogle_k562_essential/test/scgpt_finetuned.npz"))
if not npz_candidates:
    npz_candidates = list(outdir.glob("**/scgpt_finetuned.npz"))

if npz_candidates:
    data = np.load(npz_candidates[0], allow_pickle=True)
    # Convert to benchmark format
    np.savez(outdir / "predictions.npz",
             test_perts=data["pert_names"],
             predictions=data["y_pred"] - data["control_mean"],  # delta
             true_deltas=data["y_true"] - data["control_mean"],  # delta
             train_mean=data["control_mean"],
             ctrl_mean=data["control_mean"])
    print(f"Converted to benchmark format: {outdir}/predictions.npz")
else:
    print("WARNING: No scGPT output found to convert")
PYEOF
