module load miniforge/25.9.1
eval "$(conda shell.bash hook)"
conda activate agop
export PYTHONNOUSERSITE=1
set -eo pipefail

BENCH="/mnt/storage01/home/amolina/benchmark_2026"

python3 -u << 'EOF'
"""
Step 1: Convert replogle.h5ad → perturb_processed.h5ad (GEARS format)
Step 2: Compute DE (rank_genes_groups_cov_all)
"""
import json, logging
from pathlib import Path
import numpy as np
import scanpy as sc
import anndata as ad
from scipy.sparse import csr_matrix

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
logger = logging.getLogger()

BENCH = Path("/mnt/storage01/home/amolina/benchmark_2026")

CLS = {
    "k562": "replogle_k562_essential",
    "rpe1": "replogle_rpe1_essential",
    "hepg2": "nadig_hepg2",
    "jurkat": "nadig_jurkat",
}

for cl, ds in CLS.items():
    logger.info(f"\n{'='*60}")
    logger.info(f"Processing {cl} ({ds})")
    
    src = BENCH / "data" / cl / "replogle.h5ad"
    out = BENCH / "data" / cl / "perturb_processed.h5ad"
    si = json.load(open(BENCH / "data" / cl / "split_info.json"))
    
    a = sc.read_h5ad(src)
    logger.info(f"  Loaded: {a.shape}")
    
    # GEARS expects:
    # - .X = expression (dense or sparse)
    # - .obs['condition'] = 'GENE+ctrl' or 'ctrl'
    # - .obs['cell_type'] = cell line label
    # - .var_names = gene symbols (for HVG intersection)
    # - .uns['rank_genes_groups_cov_all'] = DE results
    
    # Build condition column: GEARS format is "GENE+ctrl" for single perturbations
    genes = a.obs["gene"].astype(str).values
    ctrl_label = "non-targeting"
    condition = []
    for g in genes:
        if g == ctrl_label:
            condition.append("ctrl")
        else:
            condition.append(g + "+ctrl")
    a.obs["condition"] = condition
    a.obs["cell_type"] = cl
    
    # Ensure we have gene symbols as var_names
    # X_hvg is the expression matrix in obsm — GEARS needs .X
    if "X_hvg" in a.obsm:
        # Create new adata with X_hvg as .X and hvg_names as var_names
        hvg_names = si.get("hvg_names", None)
        if hvg_names is None:
            logger.warning(f"  No hvg_names in split_info, using existing var_names")
            hvg_names = list(a.var_names[:a.obsm["X_hvg"].shape[1]])
        
        X_hvg = np.array(a.obsm["X_hvg"])
        a_new = ad.AnnData(
            X=csr_matrix(X_hvg),
            obs=a.obs.copy(),
            var=sc.AnnData(np.zeros((len(hvg_names), 0))).obs,  # minimal var
        )
        a_new.var_names = hvg_names
        a_new.var_names_make_unique()
    else:
        a_new = a.copy()
    
    logger.info(f"  GEARS format: {a_new.shape}, conditions: {a_new.obs['condition'].nunique()}")
    
    # Split info for GEARS: which perts are train/test
    train_conds = [p + "+ctrl" for p in si["train_perts"]]
    test_conds = [p + "+ctrl" for p in si["test_perts"]]
    
    # Compute DE: rank_genes_groups per condition vs ctrl, with cell_type as covariate
    logger.info(f"  Computing DE (this takes a while)...")
    
    # GEARS DE format: rank_genes_groups_cov_all
    # Keys: "{condition}_{cell_type}_1+{cell_type}_2" or similar
    # We compute: for each perturbation condition, DE vs ctrl within each cell_type
    
    from collections import defaultdict
    de_results = {}
    
    unique_conds = [c for c in a_new.obs["condition"].unique() if c != "ctrl"]
    ctrl_mask = a_new.obs["condition"] == "ctrl"
    n_ctrl = ctrl_mask.sum()
    logger.info(f"  {len(unique_conds)} conditions to process, {n_ctrl} ctrl cells")
    
    for ci, cond in enumerate(unique_conds):
        if (ci + 1) % 50 == 0:
            logger.info(f"    DE: {ci+1}/{len(unique_conds)}")
        
        cond_mask = a_new.obs["condition"] == cond
        n_cond = cond_mask.sum()
        if n_cond < 5:
            continue
        
        # Subset to this condition + ctrl
        subset = a_new[ctrl_mask | cond_mask].copy()
        
        try:
            sc.tl.rank_genes_groups(
                subset,
                groupby="condition",
                reference="ctrl",
                method="wilcoxon",
                n_genes=len(a_new.var_names),
            )
            
            # Extract results for this condition
            rgg = subset.uns["rank_genes_groups"]
            gene_names = [str(g) for g in rgg["names"][cond]]
            scores = [float(s) for s in rgg["scores"][cond]]
            pvals = [float(p) for p in rgg["pvals_adj"][cond]]
            logfc = [float(l) for l in rgg["logfoldchanges"][cond]]
            
            # GEARS key format: "{cond}_{celltype}_1+{celltype}_2"
            # For single cell type, use: "{cond}_{celltype}"
            key = f"{cond}_{cl}"
            de_results[key] = {
                "gene_names": gene_names,
                "scores": scores,
                "pvals_adj": pvals,
                "logfoldchanges": logfc,
            }
        except Exception as e:
            logger.warning(f"  DE failed for {cond}: {e}")
    
    a_new.uns["rank_genes_groups_cov_all"] = de_results
    a_new.uns["top_non_dropout_de_20"] = {}
    
    # Build top_non_dropout_de_20 (GEARS uses this for training)
    for key, vals in de_results.items():
        # Top 20 DE genes by absolute score
        gene_names = vals["gene_names"]
        scores = np.abs(vals["scores"])
        top_idx = np.argsort(scores)[::-1][:20]
        a_new.uns["top_non_dropout_de_20"][key] = [gene_names[i] for i in top_idx]
    
    logger.info(f"  DE computed: {len(de_results)} conditions")
    
    # Save
    a_new.write_h5ad(out)
    logger.info(f"  Saved: {out} ({a_new.shape})")

logger.info("\nDone. All perturb_processed.h5ad created.")
EOF
